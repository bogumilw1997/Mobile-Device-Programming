package com.example.lab2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Context context;
    SharedPreferences sharedPref;
    EditText login, haslo;
    Button zaloguj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        context = getApplicationContext();
        login = findViewById(R.id.login);
        haslo = findViewById(R.id.haslo);
        zaloguj = findViewById(R.id.zaloguj);
        //sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.autor:
                Log.d("menu", "autor");
                Toast.makeText(this,"Bogumił Wierzchowski", Toast.LENGTH_LONG).show();
                break;
            case R.id.rejestracja:
                Intent rej = new Intent(context, Rejestracja.class);
                startActivity(rej);
                break;
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
}
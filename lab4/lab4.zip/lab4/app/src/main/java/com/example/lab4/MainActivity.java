package com.example.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Context context;
    EditText nazwa, cena, data;
    Button wyslij;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();
        nazwa = findViewById(R.id.edit_nazwa);
        cena = findViewById(R.id.edit_cena);
        data = findViewById(R.id.edit_data);

        wyslij = findViewById(R.id.button_wyslij);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_baza:
                break;
            case R.id.menu_zapytanie:
                Intent zapytanie_activity = new Intent(context, Zapytanie.class);
                zapytanie_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(zapytanie_activity);
                break;
            case R.id.menu_film:
                Intent film_activity = new Intent(context, Film.class);
                film_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(film_activity);
                break;
            case R.id.menu_glowna:
                Intent main_activity = new Intent(context, MainActivity.class);
                main_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(main_activity);
                break;
        }
        return true;
    }
}
package com.example.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

class RunnableHelper implements Runnable {

    public void run() {

        String serverUrl = "https://if.pw.edu.pl/~pszymanski/PUM23/send_data.php?max=100";
        URL url = null;
        try {
            url = new URL(serverUrl);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        HttpsURLConnection urlConnection =
                null;
        try {
            urlConnection = (HttpsURLConnection) url.openConnection();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            urlConnection.connect();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
public class Zapytanie extends AppCompatActivity {
    Context context;
    TextView data_zapytanie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zapytanie);
        context = getApplicationContext();
        data_zapytanie = findViewById(R.id.data_zapytanie);
        data_zapytanie.setText("ABC");

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network network = connMgr.getActiveNetwork();

        if(network != null) {

            NetworkCapabilities caps = connMgr.getNetworkCapabilities(network);
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {

                Log.d("mam", "polaczenie");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_baza:
                break;
            case R.id.menu_zapytanie:
                Intent zapytanie_activity = new Intent(context, Zapytanie.class);
                zapytanie_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(zapytanie_activity);
                break;
            case R.id.menu_film:
                Intent film_activity = new Intent(context, Film.class);
                film_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(film_activity);
                break;
            case R.id.menu_glowna:
                Intent main_activity = new Intent(context, MainActivity.class);
                main_activity.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finish();
                startActivity(main_activity);
                break;
        }
        return true;
    }
}